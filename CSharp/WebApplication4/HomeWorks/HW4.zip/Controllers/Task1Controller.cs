﻿using Microsoft.AspNetCore.Mvc;

public class Task1Controller : Controller
{
    public IActionResult Index(int? id)
    {
        ViewData["Id"] = id;
        return View();
    }
}
