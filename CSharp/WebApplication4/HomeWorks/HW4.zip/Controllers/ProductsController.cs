﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication4.Controllers
{
    public class ProductsController : Controller
    {
        public IActionResult Search(string? name, int? categoryId)
        {
            ViewData["Name"] = name;
            ViewData["CategoryId"] = categoryId;
            return View();
        }

        public IActionResult Catalog(int? category, int? page, string? sort)
        {

            ViewData["Category"] = category;
            ViewData["Page"] = page;
            ViewData["Sort"] = sort;
            return View();
        }

    }
}
