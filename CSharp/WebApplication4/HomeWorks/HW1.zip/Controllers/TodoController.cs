﻿using Microsoft.AspNetCore.Mvc;
using WebApplication4.Models;

namespace WebApplication4.Controllers
{
    public class TodoController : Controller
    {
        private static List<TodoItem> todos = new List<TodoItem>();

        public IActionResult Index()
        {
            return View(todos);
        }

        [HttpPost]
        public IActionResult Add(string title)
        {
            todos.Add(new TodoItem
            {
                id = todos.Count + 1,
                title = title,
                is_completed = false
            });

            return RedirectToAction("Index");
        }

        public IActionResult ToggleComplete(int id)
        {
            var todo = todos.FirstOrDefault(t => t.id == id);
            if (todo != null)
                todo.is_completed = !todo.is_completed;

            return RedirectToAction("Index");
        }
    }
}
