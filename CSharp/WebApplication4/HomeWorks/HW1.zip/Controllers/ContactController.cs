﻿using Microsoft.AspNetCore.Mvc;
using WebApplication4.Models;

namespace WebApplication4.Controllers
{
    public class ContactController : Controller
    {
        private static ContactForm last_message;

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Submit(ContactForm form)
        {
            last_message = form;
            return View("Result", last_message);
        }
    }
}
