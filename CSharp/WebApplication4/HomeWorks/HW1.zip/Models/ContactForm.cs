﻿namespace WebApplication4.Models
{
    public class ContactForm
    {
        public string name { get; set; }
        public string email { get; set; }
        public string message { get; set; }
    }
}
