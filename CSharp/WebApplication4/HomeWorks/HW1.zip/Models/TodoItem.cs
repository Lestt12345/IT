﻿namespace WebApplication4.Models
{
    public class TodoItem
    {
        public int id { get; set; }
        public string title { get; set; }
        public bool is_completed { get; set; }
    }
}
