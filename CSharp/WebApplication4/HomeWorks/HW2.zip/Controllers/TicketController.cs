﻿using Microsoft.AspNetCore.Mvc;
using WebApplication4.Models;

namespace WebApplication4.Controllers
{
    public class TicketController : Controller
    {
        [HttpGet]
        public IActionResult Order()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Order(TicketOrder order)
        {
            if (!ModelState.IsValid)
                return View(order);

            return View("Confirm", order);
        }
    }
}
