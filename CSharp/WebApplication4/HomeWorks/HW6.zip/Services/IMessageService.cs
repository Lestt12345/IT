﻿namespace WebApplication4.Services
{
    public interface IMessageService
    {
        string GetMessage();
    }
}