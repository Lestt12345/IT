﻿namespace WebApplication4.Services
{
    public interface IEmailService
    {
        string Send(string to);
    }
}