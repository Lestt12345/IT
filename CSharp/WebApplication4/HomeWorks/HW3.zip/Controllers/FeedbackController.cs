﻿using Microsoft.AspNetCore.Mvc;
using WebApplication4.Models;

public class FeedbackController : Controller
{
    [HttpGet]
    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Create(Feedback model)
    {
        if (model.Message != null && model.Message.ToLower().Contains("bad"))
        {
            ModelState.AddModelError("Message", "Message contains forbidden words.");
        }

        if (!ModelState.IsValid)
            return View(model);

        return View("Success");
    }
}
