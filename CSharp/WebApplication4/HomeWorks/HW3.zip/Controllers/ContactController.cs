﻿using Microsoft.AspNetCore.Mvc;
using WebApplication4.Models;

public class ContactController : Controller
{
    [HttpGet]
    public IActionResult Send()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Send(ContactForm model)
    {
        if (!ModelState.IsValid)
            return View(model);

        return View("Success", model);
    }
}
