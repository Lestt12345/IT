﻿using Microsoft.AspNetCore.Mvc;
using WebApplication4.Models;

public class AccountController : Controller
{
    [HttpGet]
    public IActionResult Register()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Register(UserRegistration model)
    {
        if (!ModelState.IsValid)
            return View(model);

        return View("Success");
    }
}
