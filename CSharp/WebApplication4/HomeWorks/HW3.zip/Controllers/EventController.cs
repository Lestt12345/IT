﻿using Microsoft.AspNetCore.Mvc;
using WebApplication4.Models;

public class EventController : Controller
{
    [HttpGet]
    public IActionResult Register()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Register(EventRegistration model)
    {
        if (model.Age < 18)
        {
            ModelState.AddModelError("Age", "You must be at least 18 years old.");
        }

        if (!ModelState.IsValid)
            return View(model);

        return View("Success", model);
    }
}
