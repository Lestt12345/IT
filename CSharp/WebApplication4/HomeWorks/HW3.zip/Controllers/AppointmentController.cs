﻿using Microsoft.AspNetCore.Mvc;
using WebApplication4.Models;

public class AppointmentController : Controller
{
    [HttpGet]
    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Create(Appointment model)
    {
        if (!ModelState.IsValid)
            return View(model);

        return View("Success", model);
    }
}
