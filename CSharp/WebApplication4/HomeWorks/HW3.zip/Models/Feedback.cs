﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication4.Models
{
    public class Feedback
    {
        [Required]
        public string Title { get; set; }

        [Required]
        public string Message { get; set; }
    }
}
