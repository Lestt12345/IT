﻿using System.ComponentModel.DataAnnotations;
using WebApplication4.Attributes;

namespace WebApplication4.Models
{
    public class Appointment
    {
        [Required]
        public string Title { get; set; }

        [NotFutureDate]
        public DateTime Date { get; set; }
    }
}
