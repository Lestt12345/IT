﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication4.Attributes
{
    public class NotFutureDateAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value == null)
                return ValidationResult.Success;

            DateTime date = (DateTime)value;

            if (date > DateTime.Today)
                return new ValidationResult("Date cannot be in the future");

            return ValidationResult.Success;
        }
    }
}
