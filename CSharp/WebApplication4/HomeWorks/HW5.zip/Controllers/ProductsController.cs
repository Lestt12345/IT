﻿using Microsoft.AspNetCore.Mvc;
using WebApplication4.Models;

public class ProductsController : Controller
{
    private static List<Product> products = new List<Product>
    {
        new Product { Name = "Book", Price = 100 },
        new Product { Name = "Phone", Price = 500 }
    };

    [HttpGet]
    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Create(Product product)
    {
        if (!ModelState.IsValid)
        {
            ViewBag.Error = "Invalid data!";
            return View(product);
        }

        products.Add(product);
        ViewBag.Info = "Product created successfully!";
        return RedirectToAction("Index");
    }

    public IActionResult Index()
    {
        return View(products);
    }
}
