using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication3.Pages
{
    public class GalleryModel : PageModel
    {
        public List<dynamic> Cards { get; set; }

        public void OnGet()
        {
            Cards = new List<dynamic>
            {
                new { Title = "Card 1", Description = "Card description 1", ImageUrl = "https://picsum.photos/id/1/600/400", Link = "#" },
                new { Title = "Card 2", Description = "Card description 2", ImageUrl = "https://picsum.photos/id/2/600/400", Link = "#" },
                new { Title = "Card 3", Description = "Card description 3", ImageUrl = "https://picsum.photos/id/3/600/400", Link = "#" },
                new { Title = "Card 4", Description = "Card description 4", ImageUrl = "https://picsum.photos/id/4/600/400", Link = "#" },
                new { Title = "Card 5", Description = "Card description 5", ImageUrl = "https://picsum.photos/id/5/600/400", Link = "#" },
                new { Title = "Card 6", Description = "Card description 6", ImageUrl = "https://picsum.photos/id/6/600/400", Link = "#" }
            };
        }
    }
}
