using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication2.Pages
{
    public class SuccessModel : PageModel
    {
        public void OnGet()
        {
        }
    }

}
